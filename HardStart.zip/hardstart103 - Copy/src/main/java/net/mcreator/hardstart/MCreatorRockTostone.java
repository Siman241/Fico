package net.mcreator.hardstart;

import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.item.ItemStack;
import net.minecraft.inventory.IInventory;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;
import net.minecraft.block.Blocks;

import java.util.HashMap;

@Elementshardstart.ModElement.Tag
public class MCreatorRockTostone extends Elementshardstart.ModElement {
	public MCreatorRockTostone(Elementshardstart instance) {
		super(instance, 23);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("entity") == null) {
			System.err.println("Failed to load dependency entity for procedure MCreatorRockTostone!");
			return;
		}
		if (dependencies.get("guiinventory") == null) {
			System.err.println("Failed to load dependency guiinventory for procedure MCreatorRockTostone!");
			return;
		}
		Entity entity = (Entity) dependencies.get("entity");
		HashMap guiinventory = (HashMap) dependencies.get("guiinventory");
		boolean number1 = false;
		double number2 = 0;
		number2 = (double) ((new Object() {
			public int getAmount(int sltid) {
				IInventory inv = (IInventory) guiinventory.get("Rock");
				if (inv != null) {
					ItemStack stack = inv.getStackInSlot(sltid);
					if (stack != null)
						return stack.getCount();
				}
				return 0;
			}
		}.getAmount((int) (0))) - 4);
		if (((new Object() {
			public int getAmount(int sltid) {
				IInventory inv = (IInventory) guiinventory.get("Rock");
				if (inv != null) {
					ItemStack stack = inv.getStackInSlot(sltid);
					if (stack != null)
						return stack.getCount();
				}
				return 0;
			}
		}.getAmount((int) (0))) >= 4)) {
			Minecraft.getInstance().player.closeScreen();
			if (entity instanceof PlayerEntity)
				ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), new ItemStack(MCreatorStone.block, (int) ((number2))));
			if (entity instanceof PlayerEntity)
				ItemHandlerHelper.giveItemToPlayer(((PlayerEntity) entity), new ItemStack(Blocks.COBBLESTONE, (int) (1)));
		}
	}
}
